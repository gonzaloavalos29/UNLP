namespace CentroEventos.Aplicacion.Servicios;

public enum Permiso
{
    EventoAlta, EventoModificacion, EventoBaja,
    ReservaBaja, ReservaAlta, ReservaModificacion,
    UsuarioBaja, UsuarioModificacion, UsuarioPermiso,
    PersonaAlta, PersonaBaja, PersonaModificar
}
