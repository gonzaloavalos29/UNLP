namespace CentroEventos.Aplicacion.Servicios;

public enum EstadoAsistencia{ Pendiente,Presente,Ausente }