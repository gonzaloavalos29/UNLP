namespace CentroEventos.Aplicacion.Excepciones;

public class OperacionInvalidaException:Exception {
    public OperacionInvalidaException(string m):base(m){}
}
